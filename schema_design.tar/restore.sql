--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 14.0
-- Dumped by pg_dump version 14.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE cooksys_schema_design;
--
-- Name: cooksys_schema_design; Type: DATABASE; Schema: -; Owner: jkrovitz
--

CREATE DATABASE cooksys_schema_design WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'en_US.UTF-8';


ALTER DATABASE cooksys_schema_design OWNER TO jkrovitz;

\connect cooksys_schema_design

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: identity_schema; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA identity_schema;


ALTER SCHEMA identity_schema OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: interest; Type: TABLE; Schema: identity_schema; Owner: postgres
--

CREATE TABLE identity_schema.interest (
    interest_id integer NOT NULL,
    title character varying(255) NOT NULL
);


ALTER TABLE identity_schema.interest OWNER TO postgres;

--
-- Name: interest_interest_id_seq; Type: SEQUENCE; Schema: identity_schema; Owner: postgres
--

CREATE SEQUENCE identity_schema.interest_interest_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE identity_schema.interest_interest_id_seq OWNER TO postgres;

--
-- Name: interest_interest_id_seq; Type: SEQUENCE OWNED BY; Schema: identity_schema; Owner: postgres
--

ALTER SEQUENCE identity_schema.interest_interest_id_seq OWNED BY identity_schema.interest.interest_id;


--
-- Name: location_table; Type: TABLE; Schema: identity_schema; Owner: postgres
--

CREATE TABLE identity_schema.location_table (
    location_id integer NOT NULL,
    city character varying(255) NOT NULL,
    state character varying(255) NOT NULL,
    country character varying(255) NOT NULL
);


ALTER TABLE identity_schema.location_table OWNER TO postgres;

--
-- Name: location_table_location_id_seq; Type: SEQUENCE; Schema: identity_schema; Owner: postgres
--

CREATE SEQUENCE identity_schema.location_table_location_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE identity_schema.location_table_location_id_seq OWNER TO postgres;

--
-- Name: location_table_location_id_seq; Type: SEQUENCE OWNED BY; Schema: identity_schema; Owner: postgres
--

ALTER SEQUENCE identity_schema.location_table_location_id_seq OWNED BY identity_schema.location_table.location_id;


--
-- Name: person; Type: TABLE; Schema: identity_schema; Owner: postgres
--

CREATE TABLE identity_schema.person (
    person_id integer NOT NULL,
    first_name character varying(255) NOT NULL,
    last_name character varying(255) NOT NULL,
    age integer NOT NULL,
    location_id integer NOT NULL
);


ALTER TABLE identity_schema.person OWNER TO postgres;

--
-- Name: person_interest; Type: TABLE; Schema: identity_schema; Owner: postgres
--

CREATE TABLE identity_schema.person_interest (
    person_interest_id integer NOT NULL,
    person_id integer NOT NULL,
    interest_id integer NOT NULL
);


ALTER TABLE identity_schema.person_interest OWNER TO postgres;

--
-- Name: person_interest_person_interest_id_seq; Type: SEQUENCE; Schema: identity_schema; Owner: postgres
--

CREATE SEQUENCE identity_schema.person_interest_person_interest_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE identity_schema.person_interest_person_interest_id_seq OWNER TO postgres;

--
-- Name: person_interest_person_interest_id_seq; Type: SEQUENCE OWNED BY; Schema: identity_schema; Owner: postgres
--

ALTER SEQUENCE identity_schema.person_interest_person_interest_id_seq OWNED BY identity_schema.person_interest.person_interest_id;


--
-- Name: person_person_id_seq; Type: SEQUENCE; Schema: identity_schema; Owner: postgres
--

CREATE SEQUENCE identity_schema.person_person_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE identity_schema.person_person_id_seq OWNER TO postgres;

--
-- Name: person_person_id_seq; Type: SEQUENCE OWNED BY; Schema: identity_schema; Owner: postgres
--

ALTER SEQUENCE identity_schema.person_person_id_seq OWNED BY identity_schema.person.person_id;


--
-- Name: interest interest_id; Type: DEFAULT; Schema: identity_schema; Owner: postgres
--

ALTER TABLE ONLY identity_schema.interest ALTER COLUMN interest_id SET DEFAULT nextval('identity_schema.interest_interest_id_seq'::regclass);


--
-- Name: location_table location_id; Type: DEFAULT; Schema: identity_schema; Owner: postgres
--

ALTER TABLE ONLY identity_schema.location_table ALTER COLUMN location_id SET DEFAULT nextval('identity_schema.location_table_location_id_seq'::regclass);


--
-- Name: person person_id; Type: DEFAULT; Schema: identity_schema; Owner: postgres
--

ALTER TABLE ONLY identity_schema.person ALTER COLUMN person_id SET DEFAULT nextval('identity_schema.person_person_id_seq'::regclass);


--
-- Name: person_interest person_interest_id; Type: DEFAULT; Schema: identity_schema; Owner: postgres
--

ALTER TABLE ONLY identity_schema.person_interest ALTER COLUMN person_interest_id SET DEFAULT nextval('identity_schema.person_interest_person_interest_id_seq'::regclass);


--
-- Data for Name: interest; Type: TABLE DATA; Schema: identity_schema; Owner: postgres
--

COPY identity_schema.interest (interest_id, title) FROM stdin;
\.
COPY identity_schema.interest (interest_id, title) FROM '$$PATH$$/3606.dat';

--
-- Data for Name: location_table; Type: TABLE DATA; Schema: identity_schema; Owner: postgres
--

COPY identity_schema.location_table (location_id, city, state, country) FROM stdin;
\.
COPY identity_schema.location_table (location_id, city, state, country) FROM '$$PATH$$/3602.dat';

--
-- Data for Name: person; Type: TABLE DATA; Schema: identity_schema; Owner: postgres
--

COPY identity_schema.person (person_id, first_name, last_name, age, location_id) FROM stdin;
\.
COPY identity_schema.person (person_id, first_name, last_name, age, location_id) FROM '$$PATH$$/3604.dat';

--
-- Data for Name: person_interest; Type: TABLE DATA; Schema: identity_schema; Owner: postgres
--

COPY identity_schema.person_interest (person_interest_id, person_id, interest_id) FROM stdin;
\.
COPY identity_schema.person_interest (person_interest_id, person_id, interest_id) FROM '$$PATH$$/3608.dat';

--
-- Name: interest_interest_id_seq; Type: SEQUENCE SET; Schema: identity_schema; Owner: postgres
--

SELECT pg_catalog.setval('identity_schema.interest_interest_id_seq', 16, true);


--
-- Name: location_table_location_id_seq; Type: SEQUENCE SET; Schema: identity_schema; Owner: postgres
--

SELECT pg_catalog.setval('identity_schema.location_table_location_id_seq', 16, true);


--
-- Name: person_interest_person_interest_id_seq; Type: SEQUENCE SET; Schema: identity_schema; Owner: postgres
--

SELECT pg_catalog.setval('identity_schema.person_interest_person_interest_id_seq', 38, true);


--
-- Name: person_person_id_seq; Type: SEQUENCE SET; Schema: identity_schema; Owner: postgres
--

SELECT pg_catalog.setval('identity_schema.person_person_id_seq', 24, true);


--
-- Name: interest interest_pkey; Type: CONSTRAINT; Schema: identity_schema; Owner: postgres
--

ALTER TABLE ONLY identity_schema.interest
    ADD CONSTRAINT interest_pkey PRIMARY KEY (interest_id);


--
-- Name: location_table location_table_pkey; Type: CONSTRAINT; Schema: identity_schema; Owner: postgres
--

ALTER TABLE ONLY identity_schema.location_table
    ADD CONSTRAINT location_table_pkey PRIMARY KEY (location_id);


--
-- Name: person_interest person_interest_pkey; Type: CONSTRAINT; Schema: identity_schema; Owner: postgres
--

ALTER TABLE ONLY identity_schema.person_interest
    ADD CONSTRAINT person_interest_pkey PRIMARY KEY (person_interest_id);


--
-- Name: person person_pkey; Type: CONSTRAINT; Schema: identity_schema; Owner: postgres
--

ALTER TABLE ONLY identity_schema.person
    ADD CONSTRAINT person_pkey PRIMARY KEY (person_id);


--
-- Name: person_interest fk_interest; Type: FK CONSTRAINT; Schema: identity_schema; Owner: postgres
--

ALTER TABLE ONLY identity_schema.person_interest
    ADD CONSTRAINT fk_interest FOREIGN KEY (interest_id) REFERENCES identity_schema.interest(interest_id);


--
-- Name: person fk_location; Type: FK CONSTRAINT; Schema: identity_schema; Owner: postgres
--

ALTER TABLE ONLY identity_schema.person
    ADD CONSTRAINT fk_location FOREIGN KEY (location_id) REFERENCES identity_schema.location_table(location_id);


--
-- Name: person_interest fk_person; Type: FK CONSTRAINT; Schema: identity_schema; Owner: postgres
--

ALTER TABLE ONLY identity_schema.person_interest
    ADD CONSTRAINT fk_person FOREIGN KEY (person_id) REFERENCES identity_schema.person(person_id);


--
-- PostgreSQL database dump complete
--

